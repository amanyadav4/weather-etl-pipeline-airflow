from weather_etl.extract import extract_weather
from weather_etl.transform import transform_weather
from weather_etl.load import load_data

def run_etl(city):
    raw = extract_weather(city)
    transformed = transform_weather(raw)
    load_data(transformed)

if __name__ == "__main__":
    run_etl("Bhopal")
