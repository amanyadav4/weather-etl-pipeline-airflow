from sqlalchemy import create_engine
from weather_etl.config import DB_URI

def load_data(df, table_name="weather_data"):
    engine = create_engine(DB_URI)
    df.to_sql(table_name, engine, if_exists='append', index=False)
