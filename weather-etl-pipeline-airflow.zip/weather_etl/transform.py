import pandas as pd

def transform_weather(raw_data):
    transformed = {
        "city": raw_data.get("name"),
        "temperature": raw_data["main"]["temp"],
        "humidity": raw_data["main"]["humidity"],
        "weather": raw_data["weather"][0]["description"]
    }
    return pd.DataFrame([transformed])
